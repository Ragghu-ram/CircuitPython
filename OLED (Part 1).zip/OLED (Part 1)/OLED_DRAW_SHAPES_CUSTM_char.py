import board, adafruit_ssd1306, busio
from time import sleep
from draw_shapes import draw_line, draw_rectangle, draw_ellipse, draw_circle, draw_triangle, draw_polygon

# Create the I2C bus interface.
SCL = board.GP1 #change with your connection
SDA = board.GP0 #change with your connection
OLED_width = 128
OLED_height = 64

i2c = busio.I2C(SCL, SDA)

# Create the SSD1306 OLED class.
OLED = adafruit_ssd1306.SSD1306_I2C(OLED_width, OLED_height, i2c, addr=0x3c)

# fills OLED with black pixels clearing it
OLED.fill(0)
OLED.show()

cust_char = [0,4,4,31,4,4,4,0]
smiley = [0x00,0x0A,0x00,0x04,0x11,0x0E,0x00,0x00]
sad = [0x00,0x0A,0x00,0x04,0x00,0x0E,0x11,0x00]
heart = [0,0,0,10,31,14,4,0]
b_heart = [0,10,31,0,0,14,4,0]
up_arrow =[0,4,14,21,4,4,0,0]
down_arrow = [0,4,4,21,14,4,0,0]


bits = [128,64,32,16,8,4,2,1]  # Powers of 2
def char(xpos, ypos, pattern):  # Print defined character
    for line in range(8):       # 5x8 characters
        for ii in range(5):     # Low value bits only
            i = ii + 3
            dot = pattern[line] & bits[i]  # Extract bit
            if dot:  # Only print WHITE dots
                OLED.pixel(xpos+i*2, ypos+line*2, dot)
                OLED.pixel(xpos+i*2+1, ypos+line*2, dot)
                OLED.pixel(xpos+i*2, ypos+line*2+1, dot)
                OLED.pixel(xpos+i*2+1, ypos+line*2+1, dot)

char(16, 30, cust_char)    # Defined characters
char(34, 30, smiley)
char(54, 30, sad)
char(16, 10, heart)
char(34, 10, b_heart)
char(54, 10, up_arrow)
char(66, 10, down_arrow)
OLED.show()