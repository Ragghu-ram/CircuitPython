import board, adafruit_ssd1306, busio
from time import sleep
from draw_shapes import draw_line, draw_rectangle, draw_ellipse, draw_circle, draw_triangle, draw_polygon

# Create the I2C bus interface.
SCL = board.GP1 #change with your connection
SDA = board.GP0 #change with your connection
OLED_width = 128
OLED_height = 64

i2c = busio.I2C(SCL, SDA)

# Create the SSD1306 OLED class.
OLED = adafruit_ssd1306.SSD1306_I2C(OLED_width, OLED_height, i2c, addr=0x3c)

# fills OLED with black pixels clearing it
OLED.fill(0)
OLED.show()

draw_line(OLED, 10, 10, 50, 30, 1, thickness=1)  # Draw a line from (10,10) to (50,30) with color 1 (white), thickness=1
draw_rectangle(OLED, 10, 20, 50, 30, 1, fill=0, thickness=1)  # Draw a rectangle with top-left corner at (10,20), width 50, height 30, color 1 (white), no fill, thickness=1
draw_ellipse(OLED, 64, 32, 20, 10, 1, fill=0, thickness=1)  # Draw an ellipse with center at (64,32), horizontal radius 20, vertical radius 10, color 1 (white), no fill, thickness=1
draw_circle(OLED, 64, 32, 20, 1, fill=0, thickness=1)  # Draw a circle with center at (64,32), radius 20, color 1 (white), no fill, thickness=1
draw_triangle(OLED, [(60, 10), (90, 10), (75, 30)], 1, fill=0, thickness=1)  # Draw a triangle with vertices at (60,10), (90,10), and (75,30), color 1 (white), no fill, thickness=1
draw_polygon(OLED, [(100, 10), (120, 20), (110, 40), (100, 30)], 1, fill=0, thickness=1)  # Draw a polygon with vertices at (100,10), (120,20), (110,40), and (100,30), color 1 (white), no fill, thickness=1

OLED.show()


