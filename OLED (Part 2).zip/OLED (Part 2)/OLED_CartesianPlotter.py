import board, adafruit_ssd1306, busio, microcontroller

# Create the I2C bus interface.
SCL = board.GP1 #change with your connection
SDA = board.GP0 #change with your connection
OLED_width = 128
OLED_height = 64

i2c = busio.I2C(SCL, SDA)

# Create the SSD1306 OLED class.
OLED = adafruit_ssd1306.SSD1306_I2C(OLED_width, OLED_height, i2c, addr=0x3c)

# fills OLED with black pixels clearing it
OLED.fill(0)
OLED.show()

# Variables for graphing
x = 0
Redraw = True
ox, oy = 0, 0

def draw_c_graph(OLED, x, y, gx, gy, w, h, xlo, xhi, xinc, ylo, yhi, yinc, dig, title, redraw):
    global ox, oy
    if redraw:
        redraw = False
        OLED.fill_rect(0, 0, OLED_width, 16, 1)
        OLED.text(title, 2, 4, 0)
        ox = (x - xlo) * w / (xhi - xlo) + gx
        oy = (y - ylo) * (gy - h - gy) / (yhi - ylo) + gy

        # Draw y scale
        for i in range(int(ylo), int(yhi + 1), int(yinc)):
            temp = (i - ylo) * (gy - h - gy) / (yhi - ylo) + gy
            if i == 0:
                OLED.hline(gx - 3, int(temp), w + 3, 1)
            else:
                OLED.hline(gx - 3, int(temp), 3, 1)
            OLED.text(str(i), int(gx - 27), int(temp - 3), 1)


        # Draw x scale
        for i in range(int(xlo), int(xhi + 1), int(xinc)):
            temp = (i - xlo) * w / (xhi - xlo) + gx
            if i == 0:
                OLED.vline(int(temp), gy - h, h + 3, 1)
            else:
                OLED.vline(int(temp), gy, 3, 1)
            OLED.text(str(i), int(temp), gy + 6, 1)

    # Plot the data
    x_transformed = (x - xlo) * w / (xhi - xlo) + gx
    y_transformed = (y - ylo) * (gy - h - gy) / (yhi - ylo) + gy
    OLED.line(int(ox), int(oy), int(x_transformed), int(y_transformed), 1)
    OLED.line(int(ox), int(oy - 1), int(x_transformed), int(y_transformed - 1), 1)

    ox = x_transformed
    oy = y_transformed

    OLED.show()

while True:
    
    # Read analog value and convert to volts
    temp = int(microcontroller.cpu.temperature)

    # Draw the graph
    draw_c_graph(OLED, x, temp, 30, 50, 75, 30, 0, 100, 25, 0, 100, 25, 0, "Temp vs Seconds", Redraw)

    # Check if x exceeds 100
    if x > 100:
        # Clear plotting area
        OLED.fill_rect(32, 17, 96, 32, 0)
        OLED.show()
        
        # Reset x and Redraw
        x = 0
        Redraw = True
    else:
        x += 1
    #time.sleep(1)
'''

draw_c_graph(OLED, x, bvolts, 30, 50, 75, 30, 0, 100, 25, 0, 65535, 32768, 0, "Bits vs Seconds", Redraw)
   - `OLED`: This is the OLED OLED object. It's passed to the function so that the graph can be drawn on it.
   - `x`: The x-coordinate of the data point to be plotted on the graph. It's typically incremented in each iteration of the loop to move across the x-axis.
   - `bvolts`: The y-coordinate (or value) of the data point to be plotted on the graph. It's the analog reading obtained from the sensor.
   - `30, 50`: These are the coordinates of the graph's origin (left-top corner) within the OLED OLED. The graph is drawn with this origin as the reference point.
   - `75, 30`: These are the width and height of the graph area on the OLED OLED. The graph is drawn within this area.
   - `0, 100`: These are the minimum and maximum values for the x-axis (horizontal axis) of the graph.
   - `25`: This is the increment value for the x-axis. It determines the spacing between each division on the x-axis.
   - `0, 65535`: These are the minimum and maximum values for the y-axis (vertical axis) of the graph. In this case, the range is from 0 to 65535, which is the range of the analog input.
   - `32768`: This is the midpoint of the y-axis range. It's used to determine the center of the graph vertically.
   - `0`: This is the increment value for the y-axis. It determines the spacing between each division on the y-axis.
   - `"Bits vs Seconds"`: This is the title of the graph, which will be OLEDed at the top of the OLED OLED.
   - `Redraw`: This is a boolean variable indicating whether the graph needs to be redrawn completely. It's typically set to `True` when the graph settings (such as scale) change.
'''