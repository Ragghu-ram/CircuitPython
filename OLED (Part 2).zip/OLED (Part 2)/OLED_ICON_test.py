import board, adafruit_ssd1306, busio, adafruit_framebuf

# Create the I2C bus interface.
SCL = board.GP1 #change with your connection
SDA = board.GP0 #change with your connection
OLED_width = 128
OLED_height = 64

i2c = busio.I2C(SCL, SDA)

# Create the SSD1306 OLED class.
OLED = adafruit_ssd1306.SSD1306_I2C(OLED_width, OLED_height, i2c, addr=0x3c)

# fills OLED with black pixels clearing it
OLED.fill(0)
OLED.show()

buffer = bytearray(b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\xfc\x3f\x00\x01\xdf\xfb\x80\x03\x03\xc0\xc0\x03\x03\xc0\xc0\x06\x06\x60\x60\x06\x0e\x70\x60\x06\x7f\xfe\x60\x07\xfe\x7f\xe0\x0f\xf0\x0f\xf0\x3e\x60\x06\x7c\x73\xc6\x63\xce\x63\xcf\xf3\xc6\xc3\x9d\xb9\xc3\xc3\x98\x19\xc3\xc3\x8c\x31\xc3\xc3\x86\x61\xc3\x63\xc3\xc3\xc6\x73\xc1\x83\xce\x3e\x60\x06\x7c\x0f\xf0\x0f\xf0\x07\xfe\x7f\xe0\x06\x7f\xfe\x60\x06\x0e\x70\x60\x06\x06\x60\x60\x03\x03\xc0\xc0\x03\x03\xc0\xc0\x01\xdf\xfb\x80\x00\xfc\x3f\x00\x00\x00\x00\x00\x00\x00\x00\x00")

# Create a FrameBuffer object
icon_width = 32
icon_height = 32
fb = adafruit_framebuf.FrameBuffer(buffer, icon_width, icon_height, adafruit_framebuf.MVLSB)

# Function to draw buffer onto OLED
def draw_buffer_to_oled(buffer, width, height, x_offset=0, y_offset=0):
    index = 0
    for y in range(height):
        for x in range(width):
            byte_index = index // 8
            bit_index = index % 8
            pixel = (buffer[byte_index] >> (7 - bit_index)) & 1
            OLED.pixel(x + x_offset, y + y_offset, pixel)
            index += 1

# Draw the buffer onto the OLED display at the desired position
draw_buffer_to_oled(buffer, icon_width, icon_height, 48, 16)

# Show the updated display
OLED.show()
