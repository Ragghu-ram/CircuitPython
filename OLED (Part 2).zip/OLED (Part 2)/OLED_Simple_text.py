import board, adafruit_ssd1306, busio, time

# Create the I2C bus interface.
SCL = board.GP1 #change with your connection
SDA = board.GP0 #change with your connection
OLED_width = 128
OLED_height = 64

i2c = busio.I2C(SCL, SDA)

# Create the SSD1306 OLED class.
OLED = adafruit_ssd1306.SSD1306_I2C(OLED_width, OLED_height, i2c, addr=0x3c)

# fills OLED with black pixels clearing it
OLED.fill(0)
OLED.text("Learn with ram",0,36,1)
OLED.show()
time.sleep(1)
OLED.fill(1)  # Clear screen WHITE
OLED.text("Learn with ram",0,36,0) # BLACK text
OLED.show()   # Update screen



