import math

def deg(oled, xx,yy):  # Draw Degree symbol
    oled.pixel(xx,yy+1,1)
    oled.pixel(xx,yy,1)
    oled.pixel(xx+1,yy,1)
    oled.pixel(xx+1,yy+1,1)

def draw_line(oled, x0, y0, x1, y1, c, thickness=1):
    dx = abs(x1 - x0)
    dy = abs(y1 - y0)
    sx = 1 if x0 < x1 else -1
    sy = 1 if y0 < y1 else -1
    if dx > dy:
        err = dx / 2
        while x0 != x1:
            for i in range(thickness):
                oled.pixel(x0, y0 + i, c)
            err -= dy
            if err < 0:
                y0 += sy
                err += dx
            x0 += sx
    else:
        err = dy / 2
        while y0 != y1:
            for i in range(thickness):
                oled.pixel(x0 + i, y0, c)
            err -= dx
            if err < 0:
                x0 += sx
                err += dy
            y0 += sy
    oled.pixel(x0, y0, c)

def draw_rectangle(oled, x0, y0, width, height, c, fill=None, thickness=1):
    x1 = x0 + width - 1
    y1 = y0 + height - 1
    for i in range(thickness):
        oled.rect(x0 + i, y0 + i, width - 2 * i, height - 2 * i, c)
    if fill is not None:
        oled.fill_rect(x0 + thickness, y0 + thickness, width - 2 * thickness, height - 2 * thickness, fill)

def draw_ellipse(oled, cx, cy, rx, ry, c, fill=0, thickness=1):
    if fill == 0:
        for angle in range(0, 360, 2):
            x3 = int(rx * math.cos(math.radians(angle)))
            y3 = int(ry * math.sin(math.radians(angle)))
            for t in range(thickness):
                oled.pixel(cx + x3 + t, cy + y3, c)
                oled.pixel(cx + x3 - t, cy + y3, c)
                oled.pixel(cx + x3, cy + y3 + t, c)
                oled.pixel(cx + x3, cy + y3 - t, c)
    elif fill == 1:
        for y in range(-ry, ry + 1):
            for x in range(-rx, rx + 1):
                if (x * x) / (rx * rx) + (y * y) / (ry * ry) <= 1:
                    for t in range(thickness):
                        oled.pixel(cx + x + t, cy + y, c)
                        oled.pixel(cx + x - t, cy + y, c)
                        oled.pixel(cx + x, cy + y + t, c)
                        oled.pixel(cx + x, cy + y - t, c)

def draw_circle(oled, cx, cy, r, c, fill=0, thickness=1):
    if fill == 0:
        for t in range(thickness):
            for angle in range(0, 360, 2):
                x3 = int((r + t) * math.cos(math.radians(angle)))
                y3 = int((r + t) * math.sin(math.radians(angle)))
                oled.pixel(cx + x3, cy + y3, c)
    elif fill == 1:
        for y in range(-r - thickness, r + thickness + 1):
            for x in range(-r - thickness, r + thickness + 1):
                if x * x + y * y <= (r + thickness) * (r + thickness):
                    oled.pixel(cx + x, cy + y, c)

def draw_triangle(oled, points, c, fill=0, thickness=1):
    def draw_line(p0, p1, color, thickness):
        if thickness == 1:
            oled.line(p0[0], p0[1], p1[0], p1[1], color)
        else:
            from math import atan2, sin, cos
            dx, dy = p1[0] - p0[0], p1[1] - p0[1]
            angle = atan2(dy, dx)
            for i in range(-thickness // 2, thickness // 2 + 1):
                offset_x = int(i * sin(angle))
                offset_y = int(i * cos(angle))
                oled.line(p0[0] + offset_x, p0[1] - offset_y, p1[0] + offset_x, p1[1] - offset_y, color)
    
    def midpoint(p0, p1):
        return ((p0[0] + p1[0]) // 2, (p0[1] + p1[1]) // 2)

    if fill == 0:
        for i in range(3):
            x0, y0 = points[i]
            x1, y1 = points[(i + 1) % 3]
            draw_line((x0, y0), (x1, y1), c, thickness)
    elif fill == 1:
        def draw_filled_triangle(pts):
            if abs(pts[0][0] - pts[1][0]) < 2 and abs(pts[1][1] - pts[2][1]) < 2:
                return
            for i in range(3):
                draw_line(pts[i], pts[(i + 1) % 3], c, 1)
            m01 = midpoint(pts[0], pts[1])
            m12 = midpoint(pts[1], pts[2])
            m20 = midpoint(pts[2], pts[0])
            draw_filled_triangle([pts[0], m01, m20])
            draw_filled_triangle([pts[1], m12, m01])
            draw_filled_triangle([pts[2], m20, m12])
            draw_filled_triangle([m01, m12, m20])

        draw_filled_triangle(points)

def draw_polygon(oled, points, c, thickness=1, fill=0):
    def draw_line(p0, p1, color, thickness):
        if thickness == 1:
            oled.line(p0[0], p0[1], p1[0], p1[1], color)
        else:
            from math import atan2, sin, cos
            dx, dy = p1[0] - p0[0], p1[1] - p0[1]
            angle = atan2(dy, dx)
            for i in range(-thickness // 2, thickness // 2 + 1):
                offset_x = int(i * sin(angle))
                offset_y = int(i * cos(angle))
                oled.line(p0[0] + offset_x, p0[1] - offset_y, p1[0] + offset_x, p1[1] - offset_y, color)
    
    def midpoint(p0, p1):
        return ((p0[0] + p1[0]) // 2, (p0[1] + p1[1]) // 2)

    if fill == 0:
        for i in range(len(points)):
            x0, y0 = points[i]
            x1, y1 = points[(i + 1) % len(points)]
            draw_line((x0, y0), (x1, y1), c, thickness)
    elif fill == 1:
        def draw_filled_polygon(pts):
            if all(abs(pts[i][0] - pts[(i + 1) % len(pts)][0]) < 2 and abs(pts[i][1] - pts[(i + 1) % len(pts)][1]) < 2 for i in range(len(pts))):
                return
            for i in range(len(pts)):
                draw_line(pts[i], pts[(i + 1) % len(pts)], c, 1)
            midpoints = [midpoint(pts[i], pts[(i + 1) % len(pts)]) for i in range(len(pts))]
            for i in range(len(pts)):
                draw_filled_polygon([pts[i], midpoints[i], midpoints[(i - 1) % len(pts)]])
            draw_filled_polygon(midpoints)

        draw_filled_polygon(points)
