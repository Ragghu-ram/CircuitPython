import board, adafruit_ssd1306, busio, time

# Create the I2C bus interface.
SCL = board.GP1 #change with your connection
SDA = board.GP0 #change with your connection
OLED_width = 128
OLED_height = 64

i2c = busio.I2C(SCL, SDA)

# Create the SSD1306 OLED class.
OLED = adafruit_ssd1306.SSD1306_I2C(OLED_width, OLED_height, i2c, addr=0x3c)


def zellers_congruence(day, month, year):
    if month < 3:
        month += 12
        year -= 1
    K = year % 100
    J = year // 100
    h = (day + (13 * (month + 1)) // 5 + K + (K // 4) + (J // 4) + 5 * J) % 7
    # Convert to day of the week (0 = Saturday, 1 = Sunday, ..., 6 = Friday)
    day_of_week = (h + 5) % 7  # Adjust to 0 = Sunday, 1 = Monday, ..., 6 = Saturday
    return day_of_week

ZC_days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday","Saturday", "Sunday"]

#Tomohiko Sakamoto's Algorithm
def tomohiko_sakamoto(d, m, y):
    t = [0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4]
    y -= m < 3
    return (y + y // 4 - y // 100 + y // 400 + t[m - 1] + d) % 7

TC_days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

def gauss_algorithm(day, month, year):
    if month < 3:
        month += 12
        year -= 1
    Y = year % 100
    C = year // 100
    h = (day + (2.6 * month - 0.2) + Y + Y // 4 + C // 4 - 2 * C) % 7
    # Convert to day of the week (0 = Saturday, 1 = Sunday, ..., 6 = Friday)
    day_of_week = int((h + 5) % 7)  # Convert to integer
    return day_of_week

GA_days = ["Thursday", "Friday", "Saturday","Sunday", "Monday", "Tuesday", "Wednesday"]

# Get inputs from the user
day = int(input("Enter the day (1-31): "))
month = int(input("Enter the month (1-12): "))
year = int(input("Enter the year: "))

# Validate inputs
if not (1 <= day <= 31 and 1 <= month <= 12):
    print("Invalid date!")
else:
    # Call the function and print the result
    print("The day of the week using ZC is:", ZC_days[zellers_congruence(day, month, year)])
    print("The day of the week using TS is:", TC_days[tomohiko_sakamoto(day, month, year)])
    print("The day of the week using GA is:", GA_days[gauss_algorithm(day, month, year)])
    OLED.fill(0)
    OLED.text(ZC_days[zellers_congruence(day, month, year)],0,36,1)
    OLED.show()