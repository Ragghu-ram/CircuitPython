import board, adafruit_ssd1306, busio

# Create the I2C bus interface.
SCL = board.GP1 #change with your connection
SDA = board.GP0 #change with your connection
OLED_width = 128
OLED_height = 64

i2c = busio.I2C(SCL, SDA)

# Create the SSD1306 OLED class.
oled = adafruit_ssd1306.SSD1306_I2C(OLED_width, OLED_height, i2c, addr=0x3c)

# Map the result to the day of the week
days_of_week = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday","Saturday", "Sunday"]
def zellers_congruence(day, month, year):
    if month < 3:
        month += 12
        year -= 1
    K = year % 100
    J = year // 100
    h = (day + (13 * (month + 1)) // 5 + K + (K // 4) + (J // 4) + 5 * J) % 7
    # Convert to day of the week (0 = Saturday, 1 = Sunday, ..., 6 = Friday)
    day_of_week = (h + 5) % 7  # Adjust to 0 = Sunday, 1 = Monday, ..., 6 = Saturday
    return day_of_week

def is_leap_year(year):
    # Check if a year is a leap year
    if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
        return True
    return False

def get_days_in_month(year, month):
    # Determine the number of days in a month, considering leap year
    days_in_month = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    if month == 2 and is_leap_year(year):
        return 29  # February has 29 days in a leap year
    return days_in_month[month]

# Function to display a basic calendar for the current month
def display_calendar(year, month, day_of_week, today):
    num_days = get_days_in_month(year, month)

    # Calculate the starting position based on the day of the week
    x = day_of_week * 18
    y = 0

    # Clear the OLED display
    oled.fill(0)
    oled.show()

    # Days of the week labels
    day_labels = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"]

    # Display day labels
    x = 0
    for label in day_labels:
        oled.text(label, x, y, 1)
        x += 18

    x = day_of_week * 18
    y = 10

    # Display the calendar
    for day in range(1, num_days + 1):
        if day == today:
            oled.text(str(day), x, y, 1)
        else:
            oled.text(str(day), x, y, 1)
        x += 18
        day_of_week = (day_of_week + 1) % 7

        if day_of_week == 0:
            x = 0
            y += 11  # Start a new line
        
        if y >= 60: # if 5 weeks print date on top
            x = 0
            y = 10
    oled.show()

# Get input from the user
year = int(input("Enter the year: "))
month = int(input("Enter the month (1-12): "))
day = 1
week = zellers_congruence(day, month, year)

print(f"The day of the week for {day}/{month}/{year} is {days_of_week[week]}.")

# Display the calendar for the month
display_calendar(year, month, week + 1, day)

