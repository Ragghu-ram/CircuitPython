import board, adafruit_ssd1306, busio, microcontroller, time

# Create the I2C bus interface.
SCL = board.GP1 #change with your connection
SDA = board.GP0 #change with your connection
OLED_width = 128
OLED_height = 64

i2c = busio.I2C(SCL, SDA)

# Create the SSD1306 OLED class.
display = adafruit_ssd1306.SSD1306_I2C(OLED_width, OLED_height, i2c, addr=0x3c)

# Variables for graphing
x = 0
Redraw = True

# Clear display
display.fill(0)
display.show()

# Function to draw horizontal bar chart
def draw_bar_chart_h(display, curval, x, y, w, h, loval, hival, inc, dig, label, redraw):
    stepval = 0
    mx = 0
    level = 0
    data = 0
    
    if redraw:
        redraw = False
        display.fill_rect(0, 0, 127, 16, 1)  # White rectangle for the label
        display.text(label, 2, 4, 0)  # Draw the label
        # step val basically scales the hival and low val to the width
        
        stepval = int(inc * (w / (hival - loval)) - 0.00001)
        # draw the text
        for i in range(0, w + 1, stepval):
            display.line(i + x, y, i + x, y + 5, 1)  # Draw vertical scale lines
            # Draw scale labels
            display.text(str(int((i * (inc / stepval)) + loval)), i + x, y + 10, 1)
            #print(str(int((i * (inc / stepval)) + loval)), i + x, y + 10, 1)  # Print for testing
            
    # compute level of bar graph that is scaled to the width and the hi and low vals
    # this is needed to accommodate for +/- range capability
    level = int(w * (((curval - loval) / (hival - loval))))
    
    # draw the bar graph
    # write an upper and lower bar to minimize flicker caused by blanking out bar and redraw on update
    display.fill_rect(x + level, y - h, w - level, h, 0)  # Fill the lower part of the bar
    display.rect(x, y - h, w, h, 1)  # Outline of the bar graph
    display.fill_rect(x, y - h, level, h, 1)  # Fill the upper part of the bar
    
    display.show()

# Example usage
x_pos = 5
y_pos = 40
bar_width = 115
bar_height = 20
min_val = 1
max_val = 100
increment = 20
digits = 2
graph_label = "Example Graph"
should_redraw = True

while True:
    # Example data (replace this with your actual data source)
    data_value = int(microcontroller.cpu.temperature)
    # Call the function to draw the horizontal bar chart
    draw_bar_chart_h(display, data_value, x_pos, y_pos, bar_width, bar_height, min_val, max_val, increment, digits, graph_label, should_redraw)



