import board
import busio
import adafruit_ssd1306
import time
from digitalio import DigitalInOut, Direction, Pull
import rtc

# Create the I2C bus interface
SCL = board.GP1  # Change this if needed
SDA = board.GP0  # Change this if needed
i2c = busio.I2C(SCL, SDA)

# OLED display dimensions
OLED_width = 128
OLED_height = 64

# Create the SSD1306 OLED class
OLED = adafruit_ssd1306.SSD1306_I2C(OLED_width, OLED_height, i2c, addr=0x3c)

# Clear the display
OLED.fill(0)
OLED.show()

# Initialize the RTC (Real Time Clock)
rtc = rtc.RTC()

# Function to format the time as a 12-hour format string
def get_time_string():
    current_time = rtc.datetime
    hour = current_time.tm_hour
    am_pm = "AM" if hour < 12 else "PM"
    hour = hour % 12
    if hour == 0:
        hour = 12
    return "{:02}:{:02}:{:02} {}".format(hour, current_time.tm_min, current_time.tm_sec, am_pm)

# Function to format the date as a string
def get_date_string():
    current_date = rtc.datetime
    return "{:02}/{:02}/{:04}".format(current_date.tm_mday, current_date.tm_mon, current_date.tm_year)

# Main loop
while True:
    # Clear the display
    OLED.fill(0)
    
    # Get the current date and time as strings
    date_string = get_date_string()
    time_string = get_time_string()
    
    # Display the date and time on the OLED
    OLED.text(date_string, 0, 20, 1)
    OLED.text(time_string, 0, 40, 1)
    
    # Update the display
    OLED.show()
    
    # Wait for one second
    time.sleep(1)

