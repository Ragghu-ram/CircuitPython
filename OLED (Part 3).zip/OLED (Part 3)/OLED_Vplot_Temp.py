import board, adafruit_ssd1306, busio, microcontroller

# Create the I2C bus interface.
SCL = board.GP1 #change with your connection
SDA = board.GP0 #change with your connection
OLED_width = 128
OLED_height = 64

i2c = busio.I2C(SCL, SDA)

# Create the SSD1306 OLED class.
display = adafruit_ssd1306.SSD1306_I2C(OLED_width, OLED_height, i2c, addr=0x3c)

# Variables for graphing
x = 0
Redraw = True

# Clear display
display.fill(0)
display.show()

def draw_bar_chart_v(display, curval, x, y, w, h, loval, hival, inc, dig, label, redraw):
    stepval = 0
    my = 0
    level = 0
    data = 0
    
    if redraw:
        redraw = False
        display.fill_rect(0, 0, 127, 14, 1)  # White rectangle for the label
        display.text(label, 2, 4, 0)  # Draw the label
        #stepval = int(inc * (h / (hival - loval)) - 0.001)  # Calculate the step value for the scale
        stepval = int(inc * (h / (hival - loval)) + 1)
        for i in range(0, h + 1, stepval):
            my = y - h + i
            display.line(x + w + 1, my, x + w + 6, my, 1)  # Draw scale lines
            # Draw scale labels
            display.text(str(int(hival - (i * (inc / stepval)))), x + w + 12, my - 3, 1)
    
    # Compute the level of the bar graph scaled to the height and the hi and low vals
    level = int(h * (((curval - loval) / (hival - loval))))
    
    # Draw the bar graph
    display.rect(x, y - h, w, h, 1)  # Outline of the bar graph
    display.fill_rect(x, y - h, w, h - level, 0)  # Fill the lower part of the bar
    display.rect(x, y - h, w, h, 1)  # Redraw the outline to minimize flickering
    display.fill_rect(x, y - level, w, level, 1)  # Fill the upper part of the bar
    
    display.show()


# Example usage
x_pos = 15
y_pos = 60
bar_width = 40
bar_height = 40

min_val = 0
max_val = 100
increment = 20
digits = 2
graph_label = "Temp Graph"
should_redraw = True

# Example data (replace this with your actual data source)
data_value = 20
while True:
    data_value = int(microcontroller.cpu.temperature)
    # Call the function to draw the vertical bar graph
    draw_bar_chart_v(display, data_value, x_pos, y_pos, bar_width, bar_height, min_val, max_val, increment, digits, graph_label, should_redraw)



