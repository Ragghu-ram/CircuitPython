import board, adafruit_ssd1306, busio

# Create the I2C bus interface.
SCL = board.GP1 #change with your connection
SDA = board.GP0 #change with your connection
OLED_width = 128
OLED_height = 64

i2c = busio.I2C(SCL, SDA)

# Create the SSD1306 OLED class.
OLED = adafruit_ssd1306.SSD1306_I2C(OLED_width, OLED_height, i2c, addr=0x3c)

# fills OLED with black pixels clearing it
OLED.fill(0)
OLED.show()

#Pixel X position, Pixel Y position,  Pixel color (0 = black, 1 = white)
OLED.pixel(0, 0, 1)  # Set a pixel in the middle 0, 0 position.
OLED.pixel(64, 32, 1)  # Set a pixel in the middle 64, 16 position.
OLED.pixel(127, 63, 1)  # Set a pixel in the middle 127, 31 position.
OLED.show()




